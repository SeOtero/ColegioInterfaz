package ar.org.centro8.colegio.enums;

public enum Turno {
	MAÑANA,
	TARDE,
	NOCHE
}
