function cargar() {
    //console.log('cargando elementos!')
}

//Cargando Hora
function ActualizarHora() {
    date = new Date()
    segundos = date.getSeconds()
    minutos = date.getMinutes()
    horas = date.getHours()

    hora = horas.toString().padStart(2, "0") + ":" +
        minutos.toString().padStart(2, "0") + ":" +
        segundos.toString().padStart(2, "0")
    fecha = date.getDate().toString().padStart(2, "0") + "/" +
        (date.getMonth() + 1).toString().padStart(2, "0") + "/" +
        (date.getYear() + 1900).toString().padStart(4, "0")
    document.getElementById('fecha').value = fecha
    document.getElementById('hora').setAttribute('value', hora)
}

setInterval(ActualizarHora, 1000)

