package ar.org.centro8.colegio.controllers;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import ar.org.centro8.colegio.entities.Alumno;
import ar.org.centro8.colegio.entities.Curso;
import ar.org.centro8.colegio.repositories.AlumnoRepository;
import ar.org.centro8.colegio.repositories.CursoRepository;

@Controller
public class ControllerWebAlumno {

    @Autowired
    private AlumnoRepository ar;
    @Autowired
    private CursoRepository cr;

    private String mensajeA = "Ingrese un nuevo alumno!";

    @GetMapping("/index")
    public String getIndex(Model model) {
        
        return "index";
    }

    @GetMapping("/alumnos")
    public String alumnos(
        @RequestParam(name="buscarAlumno",defaultValue = "", required = false) String buscarAlumno,
            Model model
            ){
                model.addAttribute("mensajeA", mensajeA);
                model.addAttribute("alumno", new Alumno());
                model.addAttribute("lista", ar.findAll());
                model.addAttribute("listaCurso", ((List<Curso>) cr.findAll()));
                model.addAttribute("listaApellido", ((List<Alumno>) ar.findAll())
                    .stream()
                    .filter(a -> a.getApellido().toLowerCase().contains(buscarAlumno.toLowerCase()))
                    .toList());
       
        return "alumnos";
    }

    @PostMapping("/saveAlumno")
    public String save(@ModelAttribute Alumno alumno){
      
        ar.save(alumno);

        
        if(alumno.getId()>0){
            mensajeA="se guardo el alumno id:"+alumno.getId()+"!";
        }else{
            mensajeA="no se pudo guardar el alumno";
        };

        return "redirect:alumnos";
    }

}
